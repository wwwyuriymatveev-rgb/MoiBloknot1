package ru.moi.bloknot;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.graphics.Color;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db;
    LinearLayout page, list;
    EditText search;
    boolean dark = false;
    int bg, fg, muted, card;
    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        dark = getPreferences(0).getBoolean("dark", false);
        render();
    }
    void colors() {
        bg = dark ? Color.rgb(25,27,31) : Color.rgb(247,245,239);
        fg = dark ? Color.rgb(245,242,235) : Color.rgb(35,37,40);
        muted = dark ? Color.rgb(170,174,180) : Color.rgb(117,119,121);
        card = dark ? Color.rgb(39,43,49) : Color.WHITE;
    }
    TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(fg); if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    GradientDrawableRound drawable(int color) {
        return new GradientDrawableRound(color, dp(18));
    }
    void render() {
        colors();
        page = new LinearLayout(this); page.setOrientation(1); page.setPadding(dp(20),dp(18),dp(20),dp(12)); page.setBackgroundColor(bg);
        setContentView(page);

        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Мой Блокнот", 27, true);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        Button theme = new Button(this); theme.setText(dark ? "☀" : "☾"); theme.setTextSize(18);
        theme.setOnClickListener(v -> { dark=!dark; getPreferences(0).edit().putBoolean("dark",dark).apply(); render(); });
        top.addView(theme); page.addView(top);

        TextView sub = text("Ваши мысли — всегда под рукой", 13, false); sub.setTextColor(muted);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2); sp.topMargin=dp(4); page.addView(sub,sp);

        search = new EditText(this); search.setSingleLine(true); search.setTextSize(15);
        search.setHint("Поиск по заметкам"); search.setPadding(dp(15),0,dp(15),0);
        search.setBackground(drawable(card)); search.setTextColor(fg); search.setHintTextColor(muted);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1,dp(50)); ep.topMargin=dp(20); page.addView(search,ep);

        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView label = text("Мои заметки",18,true);
        row.addView(label,new LinearLayout.LayoutParams(0,-2,1));
        TextView count = text(db.count()+" записей",12,false); count.setTextColor(muted); row.addView(count);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1,-2); rp.topMargin=dp(22); rp.bottomMargin=dp(10); page.addView(row,rp);

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this); list.setOrientation(1); scroll.addView(list);
        page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        Button add = new Button(this); add.setText("+  Новая заметка"); add.setTextSize(16);
        add.setTextColor(Color.WHITE); add.setAllCaps(false); add.setBackground(drawable(Color.rgb(90,105,80)));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1,dp(54)); ap.topMargin=dp(12); page.addView(add,ap);
        add.setOnClickListener(v -> editNote(null));

        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){ load(s.toString()); }
            public void afterTextChanged(Editable e){}
        });
        load("");
    }
    void load(String q) {
        list.removeAllViews();
        Cursor c = db.get(q);
        if (c.getCount()==0) {
            TextView empty=text(q.isEmpty()?"Пока нет заметок.\nНажмите «Новая заметка», чтобы начать.":"Ничего не найдено",15,false);
            empty.setTextColor(muted); empty.setGravity(Gravity.CENTER); empty.setPadding(dp(12),dp(50),dp(12),dp(50)); list.addView(empty);
        }
        while(c.moveToNext()) {
            final long id=c.getLong(0); String title=c.getString(1), body=c.getString(2), date=c.getString(3); boolean pin=c.getInt(4)==1;
            LinearLayout item=new LinearLayout(this); item.setOrientation(1); item.setPadding(dp(16),dp(14),dp(16),dp(12)); item.setBackground(drawable(card));
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2); ip.bottomMargin=dp(10); list.addView(item,ip);
            LinearLayout line=new LinearLayout(this); line.setGravity(Gravity.CENTER_VERTICAL);
            TextView name=text((pin?"📌 ":"")+(title.isEmpty()?"Без названия":title),17,true);
            line.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            TextView more=text("⋮",24,true); more.setPadding(dp(12),0,0,0); line.addView(more);
            more.setOnClickListener(v -> menu(id,pin));
            item.addView(line);
            TextView preview=text(body,14,false); preview.setTextColor(muted); preview.setMaxLines(3);
            LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.topMargin=dp(7); item.addView(preview,bp);
            TextView stamp=text(date,11,false); stamp.setTextColor(muted);
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2); tp.topMargin=dp(10); item.addView(stamp,tp);
            item.setOnClickListener(v -> editNote(id));
        }
        c.close();
    }
    void menu(long id, boolean pin) {
        String[] opts={pin?"Открепить":"Закрепить","Удалить"};
        new AlertDialog.Builder(this).setItems(opts,(d,w)->{
            if(w==0) db.pin(id,!pin);
            else new AlertDialog.Builder(this).setMessage("Удалить заметку?").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(x,y)->{db.delete(id);load(search.getText().toString());}).show();
            load(search.getText().toString());
        }).show();
    }
    void editNote(Long id) {
        String oldTitle="",oldBody="";
        if(id!=null){ Cursor c=db.one(id); if(c.moveToFirst()){oldTitle=c.getString(1);oldBody=c.getString(2);} c.close(); }
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(dp(20),dp(8),dp(20),0);
        EditText title=new EditText(this); title.setSingleLine(true); title.setHint("Заголовок"); title.setText(oldTitle);
        EditText body=new EditText(this); body.setGravity(Gravity.TOP); body.setMinLines(7); body.setHint("Текст заметки"); body.setText(oldBody);
        box.addView(title); box.addView(body);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(id==null?"Новая заметка":"Редактировать заметку")
            .setView(box).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",null).create();
        dialog.setOnShowListener(x -> dialog.getButton(-1).setOnClickListener(v -> {
            String t=title.getText().toString().trim(), b=body.getText().toString().trim();
            if(t.isEmpty() && b.isEmpty()){ Toast.makeText(this,"Введите текст заметки",Toast.LENGTH_SHORT).show(); return; }
            if(id==null) db.add(t,b); else db.update(id,t,b);
            dialog.dismiss(); load(search.getText().toString());
            ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(body.getWindowToken(),0);
        }));
        dialog.show();
    }
    class DB extends SQLiteOpenHelper {
        DB(Context c){super(c,"notes.db",null,1);}
        public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,body TEXT,stamp TEXT,pinned INTEGER DEFAULT 0)");}
        public void onUpgrade(SQLiteDatabase d,int a,int b){}
        String now(){return new SimpleDateFormat("dd.MM.yyyy  HH:mm",Locale.getDefault()).format(new Date());}
        void add(String t,String b){ContentValues v=new ContentValues();v.put("title",t);v.put("body",b);v.put("stamp",now());getWritableDatabase().insert("notes",null,v);}
        void update(long id,String t,String b){ContentValues v=new ContentValues();v.put("title",t);v.put("body",b);v.put("stamp",now());getWritableDatabase().update("notes",v,"id=?",new String[]{""+id});}
        void pin(long id,boolean p){ContentValues v=new ContentValues();v.put("pinned",p?1:0);getWritableDatabase().update("notes",v,"id=?",new String[]{""+id});}
        void delete(long id){getWritableDatabase().delete("notes","id=?",new String[]{""+id});}
        int count(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM notes",null);c.moveToFirst();int n=c.getInt(0);c.close();return n;}
        Cursor one(long id){return getReadableDatabase().rawQuery("SELECT id,title,body,stamp,pinned FROM notes WHERE id="+id,null);}
        Cursor get(String q){String s="%"+q.replace("'","''")+"%";return getReadableDatabase().rawQuery("SELECT id,title,body,stamp,pinned FROM notes WHERE title LIKE ? OR body LIKE ? ORDER BY pinned DESC,id DESC",new String[]{s,s});}
    }
    static class GradientDrawableRound extends android.graphics.drawable.GradientDrawable {
        GradientDrawableRound(int color,int radius){setColor(color);setCornerRadius(radius);}
    }
}
